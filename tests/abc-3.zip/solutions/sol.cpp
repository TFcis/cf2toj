#include <bits/stdc++.h>
using namespace std;
#define ll long long
int main() {
	ios::sync_with_stdio(false), cin.tie(0);
	
	ll a, b, c; cin >> a >> b >> c;
	cout << a+b+c << '\n';
}
