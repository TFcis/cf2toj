#include "testlib.h"
#include <iostream>

using namespace std;

int main(int argc, char* argv[])
{
    registerGen(argc, argv, 1);
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    int c = atoi(argv[3]);
    a = rnd.next(a/10, atoi(argv[1]));
    b = rnd.next(b/10, atoi(argv[2]));
    c = rnd.next(c/10, atoi(argv[3]));
    cout << a << endl;
    cout << b << endl;
    cout << c << endl;
}
