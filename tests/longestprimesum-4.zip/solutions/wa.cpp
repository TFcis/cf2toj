#include <iostream>
using namespace std;
int main() {
	int n; cin >> n;
	if(n & 1) {
		cout << (n-3)/2 + 1 << '\n';
	} else {
		cout << n/2 << '\n';
	}
}
