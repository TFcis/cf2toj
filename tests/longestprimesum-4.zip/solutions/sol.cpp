#include <iostream>
using namespace std;
int main() {
	long long n; cin >> n;
	cout << n/2 << '\n';
}
