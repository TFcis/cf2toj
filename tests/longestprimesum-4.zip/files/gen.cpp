#include "testlib.h"
#include <iostream>

using namespace std;

int main(int argc, char* argv[])
{
    registerGen(argc, argv, 1);
    int a = atoi(argv[1]);
    long long n = 1e9;
    long long n2 = 1e18;
    if(a == 1) {
        cout << rnd.next(2LL, n) << '\n';
    } else {
        cout << rnd.next(n, n2) << '\n';
    }
}
